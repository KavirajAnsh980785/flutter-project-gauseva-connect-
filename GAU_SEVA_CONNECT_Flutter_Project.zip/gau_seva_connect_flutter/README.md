# GAU SEVA CONNECT — Flutter App

A Flutter UI prototype for the GAU SEVA CONNECT Startup & Entrepreneurship project.

## Included screens (8)
1. Dashboard
2. Gaushala Directory
3. Animal Records
4. Care & Health
5. Support Requests
6. Donors
7. Volunteers
8. Reports

## Requirements
- Flutter SDK (stable)
- Android Studio / VS Code
- Android emulator or physical Android phone

## Run the project
Open a terminal in this folder and run:

```bash
flutter doctor
flutter pub get
flutter run
```

If you do not have a project scaffold yet, this folder already contains `pubspec.yaml` and `lib/main.dart`.

## Features in this prototype
- Responsive Material 3 interface
- Navigation drawer for all 8 screens
- Dashboard cards and quick actions
- Add animal record dialog
- Create support request dialog
- Sample directory, health, donor and volunteer data
- Simple report bars

## Important
This is a front-end demonstration. Data is stored in memory and resets when the app restarts.
The names, counts and contribution amounts are sample data for demonstration only.
There is no live login, cloud database, payment gateway, donor transaction processing, push notification or veterinarian integration yet.
Before real use, connect a secure backend (for example, Firebase or your own REST API), implement role-based access, consent, backups and verified financial records.
