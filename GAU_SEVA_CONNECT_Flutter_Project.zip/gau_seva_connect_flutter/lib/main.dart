import 'package:flutter/material.dart';

void main() => runApp(const GauSevaConnectApp());

const Color forest = Color(0xFF145A42);
const Color leaf = Color(0xFF2F8060);
const Color gold = Color(0xFFD6A84F);
const Color cream = Color(0xFFF6F8F4);
const Color ink = Color(0xFF24332C);

class GauSevaConnectApp extends StatelessWidget {
  const GauSevaConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GAU SEVA CONNECT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: forest, primary: forest),
        appBarTheme: const AppBarTheme(
          backgroundColor: cream, foregroundColor: ink, elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: Colors.white, elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: const Color(0xFFF3F6F2),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final List<String> titles = const [
    'Dashboard', 'Gaushala Directory', 'Animal Records', 'Care & Health',
    'Support Requests', 'Donors', 'Volunteers', 'Reports'
  ];
  final List<IconData> icons = const [
    Icons.dashboard_rounded, Icons.home_work_rounded, Icons.pets_rounded,
    Icons.health_and_safety_rounded, Icons.volunteer_activism_rounded,
    Icons.favorite_rounded, Icons.groups_rounded, Icons.bar_chart_rounded
  ];

  final List<Map<String, String>> animals = [
    {'id':'GSC-001','name':'Gauri','age':'4 years','health':'Healthy','centre':'Demo Gaushala A'},
    {'id':'GSC-002','name':'Nandini','age':'6 years','health':'Under treatment','centre':'Demo Gaushala B'},
    {'id':'GSC-003','name':'Kamdhenu','age':'3 years','health':'Healthy','centre':'Demo Gaushala A'},
    {'id':'GSC-004','name':'Sita','age':'5 years','health':'Vaccination due','centre':'Demo Gaushala C'},
  ];
  final List<Map<String, String>> centres = [
    {'name':'Demo Gaushala A','location':'Lucknow','animals':'42','status':'Verified'},
    {'name':'Demo Gaushala B','location':'Sitapur','animals':'28','status':'Pending review'},
    {'name':'Demo Gaushala C','location':'Barabanki','animals':'55','status':'Verified'},
    {'name':'Demo Gaushala D','location':'Unnao','animals':'31','status':'Verified'},
  ];
  final List<Map<String, String>> requests = [
    {'title':'Green fodder requirement','centre':'Demo Gaushala A','amount':'₹18,000','status':'Open'},
    {'title':'Veterinary support','centre':'Demo Gaushala B','amount':'₹12,500','status':'In progress'},
    {'title':'Repair of animal shed','centre':'Demo Gaushala C','amount':'₹25,000','status':'Open'},
  ];
  final List<Map<String, String>> donors = [
    {'name':'Aarav Sharma','contribution':'₹5,000','date':'02 Nov 2026'},
    {'name':'Meera Verma','contribution':'₹2,500','date':'01 Nov 2026'},
    {'name':'Rohan Gupta','contribution':'₹1,000','date':'29 Oct 2026'},
  ];
  final List<Map<String, String>> volunteers = [
    {'name':'Priya Singh','skill':'Event coordination','availability':'Weekends'},
    {'name':'Aditya Mishra','skill':'Veterinary assistance','availability':'Flexible'},
    {'name':'Sana Khan','skill':'Social media','availability':'Evenings'},
  ];

  void addAnimal() async {
    final name = TextEditingController();
    final age = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Add animal record'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText:'Animal name')),
        const SizedBox(height:10),
        TextField(controller: age, decoration: const InputDecoration(labelText:'Age / estimate')),
      ]),
      actions: [TextButton(onPressed:()=>Navigator.pop(ctx,false), child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true), child:const Text('Save'))],
    ));
    if (result == true && name.text.trim().isNotEmpty) {
      setState(() => animals.add({'id':'GSC-${(animals.length+1).toString().padLeft(3,'0')}',
        'name':name.text.trim(),'age':age.text.trim().isEmpty?'Not specified':age.text.trim(),
        'health':'Healthy','centre':'Demo Gaushala A'}));
    }
  }

  void addRequest() async {
    final title = TextEditingController();
    final amount = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Create support request'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller:title, decoration:const InputDecoration(labelText:'Requirement')),
        const SizedBox(height:10),
        TextField(controller:amount, keyboardType:TextInputType.number,
          decoration:const InputDecoration(labelText:'Estimated amount (₹)')),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Create'))],
    ));
    if (result == true && title.text.trim().isNotEmpty) {
      setState(()=>requests.insert(0, {'title':title.text.trim(),'centre':'Demo Gaushala A',
        'amount':amount.text.trim().isEmpty?'To be estimated':'₹${amount.text.trim()}','status':'Open'}));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(width:36,height:36,decoration:BoxDecoration(color:forest,borderRadius:BorderRadius.circular(11)),
            child:const Icon(Icons.pets,color:Colors.white,size:21)),
          const SizedBox(width:10),
          Flexible(child: Text(titles[selected],style:const TextStyle(fontWeight:FontWeight.w800))),
        ]),
        actions:[IconButton(onPressed:()=>_showProfile(context),icon:const CircleAvatar(
          radius:16,backgroundColor:Color(0xFFE3EDE5),child:Icon(Icons.person,color:forest,size:19)))],
      ),
      drawer: _buildDrawer(),
      body: _page(),
      floatingActionButton: selected == 2
          ? FloatingActionButton.extended(onPressed:addAnimal,icon:const Icon(Icons.add),label:const Text('Add animal'))
          : selected == 4
              ? FloatingActionButton.extended(onPressed:addRequest,icon:const Icon(Icons.add),label:const Text('New request'))
              : null,
    );
  }

  Widget _buildDrawer() => NavigationDrawer(
    selectedIndex:selected,
    onDestinationSelected:(i){setState(()=>selected=i);Navigator.pop(context);},
    children:[
      Padding(padding:const EdgeInsets.fromLTRB(24,24,20,20),child:Row(children:[
        Container(width:48,height:48,decoration:BoxDecoration(color:forest,borderRadius:BorderRadius.circular(15)),
          child:const Icon(Icons.pets,color:Colors.white,size:27)),
        const SizedBox(width:12),
        const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('GAU SEVA CONNECT',style:TextStyle(fontWeight:FontWeight.w900,color:forest,fontSize:14)),
          Text('Care • Connect • Contribute',style:TextStyle(fontSize:11,color:Colors.black54)),
        ])),
      ])),
      const Padding(padding:EdgeInsets.fromLTRB(28,8,16,8),child:Text('WORKSPACE',
        style:TextStyle(fontSize:11,fontWeight:FontWeight.bold,color:Colors.black45,letterSpacing:1.2))),
      for(int i=0;i<titles.length;i++)
        NavigationDrawerDestination(icon:Icon(icons[i]),label:Text(titles[i])),
      const Padding(padding:EdgeInsets.fromLTRB(28,20,16,8),child:Text('ACCOUNT',
        style:TextStyle(fontSize:11,fontWeight:FontWeight.bold,color:Colors.black45,letterSpacing:1.2))),
      const NavigationDrawerDestination(icon:Icon(Icons.settings_outlined),label:Text('Settings')),
    ],
  );

  Widget _page() {
    switch(selected) {
      case 0: return DashboardPage(animals:animals,centres:centres,requests:requests,onOpen:(i)=>setState(()=>selected=i));
      case 1: return DirectoryPage(centres:centres);
      case 2: return AnimalPage(animals:animals,onAdd:addAnimal);
      case 3: return CarePage(animals:animals);
      case 4: return RequestPage(requests:requests,onAdd:addRequest);
      case 5: return DonorPage(donors:donors);
      case 6: return VolunteerPage(volunteers:volunteers);
      case 7: return ReportsPage(animals:animals,centres:centres,requests:requests);
      default: return const Center(child:Text('Settings will be available in the next version.'));
    }
  }

  void _showProfile(BuildContext context) => showDialog(context:context,builder:(ctx)=>AlertDialog(
    title:const Text('Administrator profile'),
    content:const Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('GAU SEVA CONNECT Demo Admin',style:TextStyle(fontWeight:FontWeight.bold)),
      SizedBox(height:8),Text('Role: Platform Administrator'),
      Text('This is a local demonstration profile.'),
    ]),
    actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Close'))],
  ));
}

class PageBody extends StatelessWidget {
  final Widget child;
  const PageBody({super.key,required this.child});
  @override Widget build(BuildContext context)=>SingleChildScrollView(
    padding:const EdgeInsets.fromLTRB(18,12,18,90),child:child);
}

class DashboardPage extends StatelessWidget {
  final List<Map<String,String>> animals,centres,requests;
  final ValueChanged<int> onOpen;
  const DashboardPage({super.key,required this.animals,required this.centres,required this.requests,required this.onOpen});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Container(width:double.infinity,padding:const EdgeInsets.all(22),decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[forest,leaf]),borderRadius:BorderRadius.circular(22)),
      child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Namaste! Welcome back',style:TextStyle(color:Colors.white70)),
        SizedBox(height:8),Text('Every act of care\nmakes a difference.',style:TextStyle(
          color:Colors.white,fontSize:25,fontWeight:FontWeight.w900,height:1.15)),
        SizedBox(height:12),Text('Manage gaushalas, animal care and community support in one place.',
          style:TextStyle(color:Colors.white70,height:1.4)),
      ])),
    const SizedBox(height:20),
    const SectionTitle('Overview','A quick view of platform activity'),
    const SizedBox(height:10),
    GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,
      childAspectRatio:1.55,crossAxisSpacing:10,mainAxisSpacing:10,children:[
        StatCard(label:'Gaushalas',value:'${centres.length}',icon:Icons.home_work,color:forest),
        StatCard(label:'Animal records',value:'${animals.length}',icon:Icons.pets,color:leaf),
        StatCard(label:'Support requests',value:'${requests.length}',icon:Icons.volunteer_activism,color:gold),
        const StatCard(label:'Active volunteers',value:'12',icon:Icons.groups,color:Color(0xFF6583A5)),
      ]),
    const SizedBox(height:20),const SectionTitle('Quick actions','Open a workspace'),
    const SizedBox(height:10),
    Wrap(spacing:10,runSpacing:10,children:[
      ActionChip(avatar:const Icon(Icons.pets,size:18),label:const Text('Animal records'),onPressed:()=>onOpen(2)),
      ActionChip(avatar:const Icon(Icons.add_box_outlined,size:18),label:const Text('Support requests'),onPressed:()=>onOpen(4)),
      ActionChip(avatar:const Icon(Icons.home_work_outlined,size:18),label:const Text('Gaushala directory'),onPressed:()=>onOpen(1)),
      ActionChip(avatar:const Icon(Icons.bar_chart,size:18),label:const Text('View reports'),onPressed:()=>onOpen(7)),
    ]),
    const SizedBox(height:20),const SectionTitle('Recent support needs','Requests that need attention'),
    const SizedBox(height:8),
    ...requests.take(3).map((r)=>RequestTile(item:r)),
    const SizedBox(height:16),
    const InfoBanner(text:'Demo data is included for presentation. Replace it with verified field data before real deployment.'),
  ]));

}

class SectionTitle extends StatelessWidget {
  final String title,subtitle;
  const SectionTitle(this.title,this.subtitle,{super.key});
  @override Widget build(BuildContext context)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:ink)),
    const SizedBox(height:3),Text(subtitle,style:const TextStyle(color:Colors.black54,fontSize:12)),
  ]);
}

class StatCard extends StatelessWidget {
  final String label,value; final IconData icon; final Color color;
  const StatCard({super.key,required this.label,required this.value,required this.icon,required this.color});
  @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
      Icon(icon,color:color,size:23),Text(value,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900,color:ink)),
      Text(label,style:const TextStyle(fontSize:12,color:Colors.black54)),
    ])));
}

class InfoBanner extends StatelessWidget {
  final String text;
  const InfoBanner({super.key,required this.text});
  @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(14),
    decoration:BoxDecoration(color:const Color(0xFFFFF5DF),borderRadius:BorderRadius.circular(14)),
    child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Icon(Icons.info_outline,color:Color(0xFF9B6B19),size:20),const SizedBox(width:9),
      Expanded(child:Text(text,style:const TextStyle(fontSize:12,height:1.4,color:Color(0xFF76551D)))),
    ]));
}

class DirectoryPage extends StatelessWidget {
  final List<Map<String,String>> centres;
  const DirectoryPage({super.key,required this.centres});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SectionTitle('Registered centres','Directory of gaushalas in the pilot network'),
    const SizedBox(height:12),
    ...centres.map((c)=>Card(child:ListTile(contentPadding:const EdgeInsets.all(12),
      leading:CircleAvatar(backgroundColor:const Color(0xFFE3EEE7),child:const Icon(Icons.home_work,color:forest)),
      title:Text(c['name']!,style:const TextStyle(fontWeight:FontWeight.bold)),
      subtitle:Text('${c['location']} • ${c['animals']} animals'),
      trailing:StatusBadge(c['status']!)))),
    const InfoBanner(text:'Centre names and counts shown here are sample demonstration entries.'),
  ]));
}

class AnimalPage extends StatelessWidget {
  final List<Map<String,String>> animals; final VoidCallback onAdd;
  const AnimalPage({super.key,required this.animals,required this.onAdd});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SectionTitle('Animal register','Basic identity and care records'),
    const SizedBox(height:12),
    ...animals.map((a)=>Card(child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:8),
      leading:CircleAvatar(backgroundColor:const Color(0xFFE5F0E8),child:const Icon(Icons.pets,color:forest)),
      title:Text(a['name']!,style:const TextStyle(fontWeight:FontWeight.bold)),
      subtitle:Text('${a['id']} • ${a['age']}\n${a['centre']}'),
      isThreeLine:true,trailing:StatusBadge(a['health']!)))),
    Align(alignment:Alignment.centerLeft,child:OutlinedButton.icon(onPressed:onAdd,
      icon:const Icon(Icons.add),label:const Text('Add animal record'))),
  ]));
}

class CarePage extends StatelessWidget {
  final List<Map<String,String>> animals;
  const CarePage({super.key,required this.animals});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SectionTitle('Care & health','Track routine care and follow-up'),
    const SizedBox(height:12),
    const Row(children:[
      Expanded(child:CareMetric(title:'Healthy',count:'2',color:leaf,icon:Icons.check_circle)),
      SizedBox(width:10),Expanded(child:CareMetric(title:'Follow-up',count:'2',color:gold,icon:Icons.event_note)),
    ]),
    const SizedBox(height:16),
    ...animals.map((a)=>Card(child:ListTile(leading:const Icon(Icons.medical_services_outlined,color:forest),
      title:Text(a['name']!),subtitle:Text('Status: ${a['health']}'),
      trailing:const Icon(Icons.chevron_right)))),
    const InfoBanner(text:'Health entries are administrative records only. Veterinary diagnosis and treatment must be provided by qualified professionals.'),
  ]));
}

class CareMetric extends StatelessWidget {
  final String title,count; final Color color; final IconData icon;
  const CareMetric({super.key,required this.title,required this.count,required this.color,required this.icon});
  @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(icon,color:color),const SizedBox(height:10),
      Text(count,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
      Text(title,style:const TextStyle(color:Colors.black54)),
    ])));
}

class RequestPage extends StatelessWidget {
  final List<Map<String,String>> requests; final VoidCallback onAdd;
  const RequestPage({super.key,required this.requests,required this.onAdd});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SectionTitle('Support requests','Needs raised by participating centres'),
    const SizedBox(height:12),
    ...requests.map((r)=>RequestTile(item:r)),
    Align(alignment:Alignment.centerLeft,child:OutlinedButton.icon(onPressed:onAdd,
      icon:const Icon(Icons.add),label:const Text('Create request'))),
  ]));
}

class RequestTile extends StatelessWidget {
  final Map<String,String> item;
  const RequestTile({super.key,required this.item});
  @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Row(children:[
    Container(width:42,height:42,decoration:BoxDecoration(color:const Color(0xFFFFF3D8),borderRadius:BorderRadius.circular(13)),
      child:const Icon(Icons.volunteer_activism,color:Color(0xFF9B6B19))),
    const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(item['title']!,style:const TextStyle(fontWeight:FontWeight.bold)),
      Text('${item['centre']} • ${item['amount']}',style:const TextStyle(fontSize:12,color:Colors.black54)),
    ])),
    StatusBadge(item['status']!),
  ])));
}

class DonorPage extends StatelessWidget {
  final List<Map<String,String>> donors;
  const DonorPage({super.key,required this.donors});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SectionTitle('Donor contributions','Sample contribution acknowledgement register'),
    const SizedBox(height:12),
    ...donors.map((d)=>Card(child:ListTile(
      leading:const CircleAvatar(backgroundColor:Color(0xFFFFF3D8),child:Icon(Icons.favorite,color:Color(0xFFB47B1C))),
      title:Text(d['name']!,style:const TextStyle(fontWeight:FontWeight.bold)),
      subtitle:Text('Received: ${d['date']}'),trailing:Text(d['contribution']!,
        style:const TextStyle(fontWeight:FontWeight.w900,color:forest))))),
    const InfoBanner(text:'Donation records in this prototype are illustrative. Connect a verified payment provider and accounting process before accepting real donations.'),
  ]));
}

class VolunteerPage extends StatelessWidget {
  final List<Map<String,String>> volunteers;
  const VolunteerPage({super.key,required this.volunteers});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SectionTitle('Volunteer network','People contributing time and skills'),
    const SizedBox(height:12),
    ...volunteers.map((v)=>Card(child:ListTile(
      leading:const CircleAvatar(backgroundColor:Color(0xFFE4EDF5),child:Icon(Icons.person,color:Color(0xFF547493))),
      title:Text(v['name']!,style:const TextStyle(fontWeight:FontWeight.bold)),
      subtitle:Text('${v['skill']} • ${v['availability']}'),
      trailing:const Icon(Icons.chevron_right)))),
    const InfoBanner(text:'Contact details and consent-based volunteer onboarding can be added when connecting a secure backend.'),
  ]));
}

class ReportsPage extends StatelessWidget {
  final List<Map<String,String>> animals,centres,requests;
  const ReportsPage({super.key,required this.animals,required this.centres,required this.requests});
  @override Widget build(BuildContext context)=>PageBody(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SectionTitle('Impact & reports','Illustrative operational summary'),
    const SizedBox(height:12),
    Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Platform snapshot',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),
      const SizedBox(height:16),
      ReportBar(label:'Animal records',value:animals.length.toDouble(),max:20,color:forest),
      ReportBar(label:'Gaushala centres',value:centres.length.toDouble(),max:10,color:leaf),
      ReportBar(label:'Open support requests',value:requests.length.toDouble(),max:10,color:gold),
    ]))),
    const SizedBox(height:12),
    const InfoBanner(text:'Charts are simple visual indicators based on local demo lists. Add validated backend data for real impact reporting.'),
  ]));
}

class ReportBar extends StatelessWidget {
  final String label; final double value,max; final Color color;
  const ReportBar({super.key,required this.label,required this.value,required this.max,required this.color});
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:14),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        Text(label),Text(value.toInt().toString(),style:const TextStyle(fontWeight:FontWeight.bold)),
      ]),
      const SizedBox(height:6),ClipRRect(borderRadius:BorderRadius.circular(20),child:LinearProgressIndicator(
        minHeight:10,value:(value/max).clamp(0.0,1.0),backgroundColor:const Color(0xFFEAF0EA),color:color)),
    ]));
}

class StatusBadge extends StatelessWidget {
  final String text;
  const StatusBadge(this.text,{super.key});
  @override Widget build(BuildContext context) {
    final bool good = text.toLowerCase().contains('verified') || text.toLowerCase().contains('healthy') || text.toLowerCase()=='open';
    final Color c = good ? forest : const Color(0xFF9A6B1D);
    return Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:6),
      decoration:BoxDecoration(color:good?const Color(0xFFE5F1E9):const Color(0xFFFFF3DB),
        borderRadius:BorderRadius.circular(20)),
      child:Text(text,style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:c)));
  }
}
